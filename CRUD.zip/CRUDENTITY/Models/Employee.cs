﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;

namespace CRUDENTITY.Models
{
    [Table("Employeeinfo")]
    public class Employee
    {
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        public string DepartmentName { get; set; }

        public decimal Salary { get; set; }
    }

    [Table("Department")]
    public class Department
    {
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }

        //public List<Employee> Employees { get; set; } = new List<Employee>();
    }
}
﻿using CRUDENTITY.Data;
using CRUDENTITY.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CRUDENTITY.Controllers
{
    public class DepartmentController : Controller
    {
        private readonly AppDbContext _context;

        public DepartmentController(AppDbContext context)
        {
            _context = context;
        }

        // READ
        public async Task<IActionResult> Index()
        {
            return View(await _context.Department.ToListAsync());
        }

        // CREATE GET
        public IActionResult Create()
        {
            return View();
        }

        // CREATE POST
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Department dept)
        {
            if (ModelState.IsValid)
            {
                _context.Add(dept);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(dept);
        }

        // EDIT GET
        public async Task<IActionResult> Edit(int id)
        {
            var dept = await _context.Department.FindAsync(id);

            if (dept == null)
                return NotFound();

            return View(dept);
        }

        // EDIT POST
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Department dept)
        {
            if (ModelState.IsValid)
            {
                _context.Update(dept);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(dept);
        }

        // DELETE
        public async Task<IActionResult> Delete(int id)
        {
            var dept = await _context.Department.FindAsync(id);

            if (dept == null)
                return NotFound();

            _context.Department.Remove(dept);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }
    }
}
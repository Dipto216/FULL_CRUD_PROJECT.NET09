﻿using CRUDENTITY.Data;
using CRUDENTITY.Models;
using Microsoft.AspNetCore.Mvc;

using Microsoft.EntityFrameworkCore;

namespace CRUDENTITY.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly AppDbContext _context;

        public EmployeeController(AppDbContext context)
        {
            _context = context;
        }

        
        public async Task<IActionResult> Index()
        {
            return View(await _context.Employeeinfo.ToListAsync());
        }

  
        public async Task<IActionResult> Create()
        {
            ViewBag.Departments = await _context.Department.ToListAsync();
            return View();
        }

       
        [HttpPost]
        public async Task<IActionResult> Create(Employee emp)
        {
            //if (!ModelState.IsValid)
            //{
            //    var errors = ModelState.Values
            //        .SelectMany(v => v.Errors)
            //        .Select(e => e.ErrorMessage)
            //        .ToList();
            //}
            if (ModelState.IsValid)
            {
                _context.Add(emp);
                await _context.SaveChangesAsync();
                return RedirectToAction("Index");
            }

            ViewBag.Departments = await _context.Department.ToListAsync();
            return View(emp);
        }

      
        public async Task<IActionResult> Edit(int id)
        {
            var emp = await _context.Employeeinfo.FindAsync(id);
            return View(emp);
        }

       
        [HttpPost]
        public async Task<IActionResult> Edit(Employee emp)
        {
            _context.Update(emp);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

   
        public async Task<IActionResult> Delete(int id)
        {
            var emp = await _context.Employeeinfo.FindAsync(id);
            _context.Remove(emp);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
    }
}

﻿

using CRUDENTITY.Models;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace CRUDENTITY.Data



{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }

        public DbSet<Employee> Employeeinfo { get; set; }
        public DbSet<Department> Department { get; set; }
    }
}
